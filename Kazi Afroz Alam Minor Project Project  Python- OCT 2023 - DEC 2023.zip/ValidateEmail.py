import re
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

def validate_email(test_string):
    pattern = r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$'
    match = re.match(pattern, test_string.strip())
    return "Valid" if bool(match) else "Invalid"

def analyze_emails(email_list):
    if not email_list:
        print("No email addresses provided.")
        return

    data = {'Email': email_list, 'Validation Status': [validate_email(email) for email in email_list]}
    df = pd.DataFrame(data)

    print("Email Addresses:\n", df)

    summary = df['Validation Status'].value_counts()
    print("\nValidation Summary:\n", summary)

    labels = ['Valid', 'Invalid']
    sizes = summary.values
    plt.pie(sizes, labels=labels, autopct='%1.1f%%', startangle=90)
    plt.title('Email Validation Summary')
    plt.show()

def main():
    emails = input("Enter a list of email addresses separated by commas: ").split(',')
    analyze_emails(emails)

if __name__ == "__main__":
    main()
