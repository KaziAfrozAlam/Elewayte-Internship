import warnings

import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
from scipy.stats import chi2_contingency

warnings.simplefilter(action='ignore', category=FutureWarning)

# Load the data from Excel file
data = pd.read_excel(r'C:\Users\ramiz\OneDrive\Desktop\ELEWAYTE MAJOR\HR analytics.xlsx')

# Convert 'Salary' column to numeric
data['Salary'] = pd.to_numeric(data['Salary'], errors='coerce')

# Objective 1: How many Males/Females are there in the entire organization?
gender_distribution = data['Gender'].value_counts()

# Objective 2: How many Males/Females are there in each department or for each location?
gender_department_distribution = data.groupby(['Department', 'Gender']).size().unstack()
gender_location_distribution = data.groupby(['Loc', 'Gender']).size().unstack()

# Objective 3: For which department is the average Pay highest?
highest_avg_pay_department = data.groupby('Department')['Salary'].mean().idxmax(skipna=True)

# Objective 4: For which location is the average Pay highest?
highest_avg_pay_location = data.groupby('Loc')['Salary'].mean().idxmax(skipna=True)

# Objective 5: What percentage of employees received good & very good rating? What about poor & very poor rating? and average rating?
if 'Ratings' in data.columns:
    rating_distribution = data['Ratings'].value_counts(normalize=True, dropna=False) * 100
else:
    rating_distribution = pd.Series([])

# Objective 6: Compute gender pay gap for each department. Interpret
gender_pay_gap_department = data.groupby(['Department', 'Gender'])['Salary'].mean().unstack()
gender_pay_gap_department['PayGap'] = (gender_pay_gap_department['Female'] - gender_pay_gap_department['Male']) / gender_pay_gap_department['Male'] * 100

# Objective 7: Compute gender pay gap for each location. Interpret
gender_pay_gap_location = data.groupby(['Loc', 'Gender'])['Salary'].mean().unstack()
gender_pay_gap_location['PayGap'] = (gender_pay_gap_location['Female'] - gender_pay_gap_location['Male']) / gender_pay_gap_location['Male'] * 100

# Additional Exercise 1: Use visualization to understand & explore data
# Example: Gender distribution bar plot
sns.countplot(x='Gender', data=data, order=data['Gender'].value_counts().index)
plt.title('Gender Distribution')
plt.show()

# Additional Exercise 2: Use statistical methods to explore the relationship/association between the variables
# Example: Boxplot to show the relationship between gender and salary
sns.boxplot(x='Gender', y='Salary', data=data.dropna(subset=['Salary']))  # Drop rows with missing Salary values
plt.title('Gender vs Salary')
plt.show()
